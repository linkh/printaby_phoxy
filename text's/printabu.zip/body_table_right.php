<?php

function body_right()
{
	echo"	
	<div class = 'body_cart'>
	<a class = 'menu_link' href = '/cart.php'>
	<p class = 'body_cart_text'>В вашей корзине пока нет товаров</p>
	</a>
	</div>
	
	<script type=\"text/javascript\" src=\"//vk.com/js/api/openapi.js?101\"></script>
		<!-- VK Widget -->
		<div id=\"vk_groups\"></div>
	<script type=\"text/javascript\">
		VK.Widgets.Group(\"vk_groups\", {mode: 2, width: \"170\", height: \"400\",  color1: 'FFFFFF', color2: 'E3DB44', color3: '00F13C'}, 20003922);
	</script>";
}