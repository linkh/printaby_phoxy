
<?php

include_once 'head.php';

?>
<!--
            <div id="content">
                <form action="upload.php" method="post" enctype="multipart/form-data" target="upload_target" onsubmit="startUpload();" >
                     <p id="f1_upload_process">Загрузка...<br/><img src="loader.gif" /><br/></p>
                     <p id="f1_upload_form" align="center"><br/>
                         <label>Картинка:  
                              <input name="myfile" type="file" size="30" />
                         </label>
                         <label>
                             <input type="submit" name="submitBtn" class="sbtn" value="Загрузить" />
                         </label>
                     </p>
                     
                     <iframe id="upload_target" name="upload_target" src="#" style="width:0;height:0;border:0px solid #fff;"></iframe>
                 </form>
             </div>
			 -->
			 
			<div class = 'builder', id = 'builder'>
				<canvas class = 'builder_canvas' id = 'builder_canvas'></canvas>
			</div>

			
<script src='builder.js'></script>
<!--//TODO add check js -->

<?php

include_once 'footer.php';