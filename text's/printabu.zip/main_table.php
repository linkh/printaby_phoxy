<?php

function startBlockWriting()
{
echo"
	<table class = 'main_table', id = 'main_table' border = '0'>
		<tr>
			<td class = 'main_space_top', id = 'main_space_top', colspan = '3'>
			</td>
		</tr>
		<tr>
			<td class = 'main_space_size', id = 'main_space_size', rowspan = '4'>
			</td>
			<td height = '1%'>
";
}

function endOfCap()
{
echo"
			</td>
			</td>
				<td class = 'main_space_size', id = 'main_space_size1', rowspan = '4'>
			</td >
		</tr>		
		<tr>
			<td>			
";
}

function footer()
{
echo"		
		<tr>
			<td class = 'footer_space'>				
			</td>
		<tr>
			<td height = 1%>	<!-- //TODO-->
					<div  class = 'footer', id = 'footer'>	
						<p> ©Exsul 2013 TODO </p>
					</div>
			</td>
		</tr>
		</tr>
	</table>
";
}