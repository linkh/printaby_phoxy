var script = document.createElement('script');
script.src = '/fabric.min.js';
document.head.appendChild(script);
script.onload = function() {


var canvas = this.__canvas = new fabric.Canvas('builder_canvas');
canvas.setWidth(500);
canvas.setHeight(600);
canvas.setBackgroundImage('/img/test.png', canvas.renderAll.bind(canvas));

var rect = new fabric.Rect({
    left: 0,
    top: 0,
    originX: 'left',
    originY: 'top',
    width: 150,
    height: 120,
    angle: -10,
    fill: 'rgba(255,0,0,1)',
    transparentCorners: false
  });

// добавляем прямоугольник, чтобы он отобразился
canvas.add(rect).setActiveObject(rect);

var rect = new fabric.Rect({
    left: 50,
    top: 50,
    originX: 'left',
    originY: 'top',
    width: 100,
    height: 120,
    angle: -10,
    fill: 'rgba(255,255,0,1)',
    transparentCorners: false
  });

canvas.add(rect).setActiveObject(rect);

//canvas.getAsFile("test.jpg", "image/jpeg");
canvas.toDataURL();
//alert(canvas.toDataURL());

var newImg = document.createElement("img");
newImg.src = canvas.toDataURL();
document.body.appendChild(newImg);
}