function chameleon()
{
	var sliding = false;
	sliding = clearInterval(sliding);	
	
	var footer, logo_text, logo, r = 0, g = 0, b = 0, temp;
	
	logo = document.getElementById("logo");
	
	footer = document.getElementById("footer");
	logo_text = document.getElementById("logo_text");
	
	sliding = setInterval (function(){
		
		r++;
		g++;
		b++;
		/*
		if (r == 255)
		{
			r = 0;
			g = 0;
			b = 0;
		}
		*/
		temp = 'rgb(' + r + ',' + g + ',' + b + ')';
		logo.style.background = temp;
		logo_text.style.color = temp;
		footer.style.background = temp;
		
	}, 100);
}