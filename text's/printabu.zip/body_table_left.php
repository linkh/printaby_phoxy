<?php

function body_left()
{
echo"
	<table class = 'menu_table'>		
		<tr>
			<td>
				<div class='menu_div'><a href='/printabu.php' class='menu_link'>О нас</a></div>
			</td>
		</tr>
		<tr>
			<td>
				<div class='menu_div'><a href='/delivery.php' class='menu_link'>Доставка</a></div>
			</td>
		</tr>
		<tr>
			<td>
				<div class='menu_div'><a href='contacts.php' class='menu_link'>Контакты</a></div>
			</td>
		</tr>
		<tr>
			<td>
				<div class='menu_div'><a href='faq.php' class='menu_link'>FAQ</a></div>
			</td>
		</tr>
		<tr>
			<td>
				<div class='menu_div'><a href='builder.php' class='menu_link'>Конструктор</a></div>
			</td>
		</tr>
	
	</table>
";
}