<?php

include_once 'head.php';

?>
<h2 class='content_head'>Контакты</h2>
<p class='content_text'>Вы можете в любой момент отправить письмо в нашу службу поддержки по адресу help@printabu.ru //TODO.
 Наши специалисты всегда готовы помочь Вам решить любую проблему и ответить на все интересующие вас вопросы.</p>

 <p class='content_text'> Если вопрос не терпит отлагательств, то вы можете позвонить по номерам +7(911) 111-11-11 и +7(911) 222-22-22</p>
<h3 class='content_head'>Написать сразу</h3>

<p class='content_text'>Также Вы можете воспользоваться нашей формой для контактов.</p>
<TEXTAREA class='content_problem'  name='problem' onfocus='content_problem_in(this)' onblur='content_problem_out(this)' >Опишите Вашу проблему</TEXTAREA>
<p class='content_text'>Пожалуйста, укажите ваш e-mail для связи.</p>

<input class = 'content_mail' type='text' name='login' value='Почта' onfocus='content_mail_in(this)' onblur='content_mail_out(this)' > <!-- //TODO name = email, type = email?-->
<form action = 'send.php'  method=\"post\" enctype=\"multipart/form-data\" target=\"upload_target\" onsubmit=\"startUpload();\" >
<input class = 'content_submit' type='button' name='send' value='Отправить' >
</form>
</div>
<?php
include_once 'footer.php';