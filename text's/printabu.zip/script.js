var script = document.createElement('script');
script.src = '/chameleon.js';
document.head.appendChild(script);

var IMG_NUM = 40; // 60
var IMG_WIDTH_DIFF = 50;
var IMG_MIN_WIDTH = 40;
var IMG_H_TO_W = 0.62;
var IMG_SPEED_DIFF = 10;
var IMG_SPEED_MIN = 20;
var IMG_OPACITY_SPEED = 0.008;

var imStr = new Array();
var parentWidth, parentHeight;

function capImg(newDiv, width, height, speed, opacity){
    this.newDiv = newDiv;
    this.width = width;
	this.height = height;
	this.speed = speed;
	this.opacity = opacity;
}

window.onresize = function ()
{
    parentWidth = document.getElementById("logo").clientWidth;
	parentHeight = document.getElementById("logo").clientHeight;	
}

window.onload = function load_cap_images()
{
    var i, newDiv, width, height, r, g, b, temp;
	var logo_test =  document.getElementById("logo_text");
	
	parentWidth = document.getElementById("logo").clientWidth;
	parentHeight = document.getElementById("logo").clientHeight;	
	
	//document.getElementById("logo").style.background = '#FF0066';
	//document.getElementById("body_table_left_div").style.background = '#DDDDDD';	 
	document.getElementById("body_table_center").style.background = '#FFFFFF';	 
	document.getElementById("footer").style.background = '#95FF74';
	//document.getElementById("main_space_size").style.background = '#CCFF99';
	//FFCE00
	//BBFFA5
	
	chameleon();
	
	'cap_table'
	//document.getElementById('main_table').style.background = document.getElementById('cap_table').style.background = document.getElementById("main_space_top").style.background = document.getElementById("main_space_size1").style.background = document.getElementById("main_space_size").style.background;
	//document.getElementById("body_table_right_div").style.background =document.getElementById("body_table_left_div").style.background;
	//document.getElementById("logo_text").style.color = document.getElementById("logo").style.background;	 
	for(i = 1; i < IMG_NUM; i++)
	{
		newDiv = document.createElement('div');
		newDiv.className = 'cap_img';
		document.getElementById("logo").insertBefore(newDiv, logo_text);					
		
		width =  parseInt(Math.random()  * (IMG_WIDTH_DIFF) + IMG_MIN_WIDTH, 10); //TODO 		
		newDiv.style.width = width;
		height = parseInt(width * IMG_H_TO_W, 10);
		newDiv.style.height = height;
		newDiv.style.top =  parseInt(Math.random()  * (parentHeight - height), 10); 
		
		temp = Math.random() * (parentWidth) - width;//TODO
		newDiv.style.right = parseInt(temp, 10);		
		
		//TODO if no image
		r = parseInt(Math.random()  * (255), 10);
		g = parseInt(Math.random()  * (255), 10);
		b = parseInt(Math.random()  * (255), 10);
		temp = 'rgb(' + r + ',' + g + ',' + b + ')';
		newDiv.style.background = temp;		
		newDiv.style.backgroundImage = "url( /img/"+i+".jpg)";
		
		temp = parseInt(Math.random()  * (IMG_SPEED_DIFF) + IMG_SPEED_MIN, 10); 
		
		imStr[i] = new capImg(newDiv, width, height, temp, 0);//TO_DO speed
		slide(imStr[i]);
	}		
}



function slide(imStruct)
{
	var sliding = false;
	var slidepos = 0;
	var top = 0, right, bottom, left = 1;	
	
	sliding = clearInterval(sliding);	
	
	slidepos = parseInt(imStruct.newDiv.style.right, 10);
	
	imStruct.opacity = 0;
	
	bottom = imStruct.height;	
	right = Math.min(Math.max(slidepos + imStruct.width, 0), imStruct.width); 
	left =  Math.max(slidepos + imStruct.width - parentWidth, 0);
	imStruct.newDiv.style.clip = "rect("+top+", "+right+", "+bottom+", "+left+")";
	
	sliding = setInterval (function(){		
		if (left == imStruct.width)
		{
			imStruct.opacity = 0;
			//imStruct.width = parseInt(Math.random()  * (IMG_WIDTH_DIFF) + IMG_MIN_WIDTH, 10); //TODO 		
			var c = Math.random() * (imStruct.width) - imStruct.width;//TODO

			imStruct.newDiv.style.right = parseInt(c, 10);
			
			slidepos = parseInt(imStruct.newDiv.style.right, 10);
				
			right = Math.min(Math.max(slidepos + imStruct.width, 0), imStruct.width); 
			left = 1;// Math.max(slidepos + imStruct.width - parentWidth, 0);
			imStruct.newDiv.style.clip = "rect("+top+", "+right+", "+bottom+", "+left+")";
		}
		else if (parentWidth - slidepos < imStruct.width )
		{
			//alert(width);
			left++;
			imStruct.newDiv.style.clip = "rect("+top+", "+right+", "+bottom+", "+left+")";
			imStruct.opacity -= IMG_OPACITY_SPEED * 2;
			imStruct.newDiv.style.opacity = imStruct.opacity;
			//alert(slidepos);
		}
		else if (right < imStruct.width)//TODO 10 - fucking skid
		{
			right++;
			imStruct.newDiv.style.clip = "rect("+top+", "+right+", "+bottom+", "+left+")";
		}
		
		if ( imStruct.opacity < 1)
		{
			imStruct.opacity += IMG_OPACITY_SPEED;
			//alert(imStruct.opacity);
			imStruct.newDiv.style.opacity = imStruct.opacity;			
		}
		//alert(slidepos);
		slidepos++;
		
		imStruct.newDiv.style.right = slidepos;			
	}, imStruct.speed);
}