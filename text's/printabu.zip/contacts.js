function content_mail_in(elem)
{
  if (elem.value == 'Почта')
      elem.value='';
}

function content_mail_out(elem)
{
  if (elem.value == '')
      elem.value='Почта';
}

function content_problem_in(elem)
{
  if (elem.value == 'Опишите Вашу проблему')
      elem.value='';
}

function content_problem_out(elem)
{
  if (elem.value == '')
      elem.value='Опишите Вашу проблему';
}

function check_email(elem)
{
}