<?php

include_once 'cap.php';
include_once 'main_table.php';
include_once 'body_table.php';


echo "<style>";
	//include_once 'style/main.css';
	//include_once 'style/style.css';
echo "</style>";

echo " 
<head>
	<meta http-equiv=\"content-type\" content=\"text/html; charset=utf-8\" />
	<script src='script.js'></script>	
	<link rel='stylesheet' href='style/main.css' type='text/css'>
	<link rel='stylesheet' href='style/style.css' type='text/css'>
	<link rel='stylesheet' href='style/cap.css' type='text/css'>
	<link rel='stylesheet' href='style/body.css' type='text/css'>
</head>";
//<script >
//include_once "script.js";


//echo " <head><script src='script.js'></script>  </head>";
//блядь, блядь, блядь!!! 
//а вроде норм сейчас

//echo " <head><link rel='stylesheet' href='main.css' type='text/css'> </head>";
//Эта ебанная пизда выше нихуя не работает как нужно. Но, кажется, так правильнее.
//кажись, прокатило

startBlockWriting();	
cap();
endOfCap();
startBody();	