<?php

include_once 'body_table_right.php';
include_once 'body_table_left.php';

function body_top()
{
echo"
	<table class = 'menu_top_table'>		
		<tr>
			<td>
				<div class='menu_div'><a href='/printabu.php' class='menu_link'>О нас</a></div>
			</td>
			<td>
				<div class='menu_div'><a href='/delivery.php' class='menu_link'>Доставка</a></div>
			</td>
			<td>
				<div class='menu_div'><a href='contacts.php' class='menu_link'>Контакты</a></div>
			</td>
			<td>
				<div class='menu_div'><a href='faq.php' class='menu_link'>FAQ</a></div>
			</td>
			<td>
				<div class='menu_div'><a href='builder.php' class='menu_link'>Конструктор</a></div>
			</td>
		</tr>
	
	</table>
";

}

function startBody()
{
echo"
				<table class = 'body_table' border = 0>
				<tr ><td colspan = '3'>
";
body_top();
echo"
				</td></tr>
					<tr>
						<td>
							<div class = 'body_table_left_div' id = 'body_table_left_div'>";

//body_left();
echo"	
							</div>
						</td>
						<!--
						<td>
							<div class = 'body_hr'></div>
						</td>
						-->
						<td class = 'body_table_center'>
							<div  class = 'body_table_center' id = 'body_table_center'>
";			
};

function endBody()
{
echo"
							</div>
						</td>
						<!--
						<td>
							<div class = 'body_hr'></div>
						</td>
						-->
						<td>
							<div  class = 'body_table_right_div' id = 'body_table_right_div'>";
body_right(); //TODO
echo"
						
							</div>
						</td>
					</tr>
				</table>
			</td>
		</tr>
";
}