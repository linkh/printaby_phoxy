<?php

include_once 'head.php';

?>


<p class="content_question">Наклейка будет выглядеть зернисто?</p> 
<p class="content_answer">Нет, мы отказались от лазерных принтеров в пользу струйных именно по этой причине.</p>

<p class="content_question">Вы работаете с другими городами?</p> 
<p class="content_answer">Да, подробнее можно почитать в разделе <a class = "content_text_link" href = "/delivery.php">доставка</a>.</p> 

<p class="content_question">Цвета не будут размазываться?</p> 
<p class="content_answer">Нет, благодаря хорошему качеству печати вам не придется об этом беспокоиться.</p>

<p class="content_question">У меня не работает конструктор! Что делать?</p> 
<p class="content_answer">Попытайтесь воспользоваться другим браузером и  <a class = "content_text_link" href = "/contacts.php">свяжитесь с нами</a>, будем разбираться.</p>

<p class="content_question">У вас есть скидки для оптовых клиентов?</p> 
<p class="content_answer">Разумеется, в случае заказа от 10 штук <a class = "content_text_link" href = "/contacts.php">напишите нам</a> и мы предоставим вам индивидуальную скидку.</p>

<p class="content_question">Наклейки не отклеятся через неделю?</p> 
<p class="content_answer">За время тестирования не было найдено ни одного человека сумевшего ненамеренно испортить наклейку.</p>

<?php
include_once 'footer.php';