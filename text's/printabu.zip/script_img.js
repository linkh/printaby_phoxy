function capImg(newimg, width, height, speed, opacity){
    this.newimg = newimg;
    this.width = width;
	this.height = height;
	this.speed = speed;
	this.opacity = opacity;
}

var imStr = new Array();
var parentWidth, parentHeight;

window.onload = function load_cap_images()
{
    var i, newimg, newDiv, width, height, newstr;
	var ls123 =  document.getElementById("logo_t");
	
	parentWidth = document.getElementById("logo").clientWidth;
	parentHeight = document.getElementById("logo").clientHeight;	
	
	for(i = 1; i < 5; i++)
	{		
		newimg = new Image();		
		newimg.setAttribute("src", '/img/'+i+'.jpg');
		newimg.className = 'cap_img'+i;
		newDiv = new Div();
		//newimg.id = 'cap_img_'+i;	
		document.getElementById("logo").insertBefore(newDiv, ls123);					
		
		width =  parseInt(Math.random()  * (100) + 100, 10); //TODO 		
		newimg.style.width = width;
		
		height = newimg.offsetHeight;		
		//alert(height);
		
		var c = Math.random() * (parentWidth) - 100;//TODO
		newimg.style.right = parseInt(c, 10);
		//alert(newimg.style.right + '_______right____'+c+'____'+width);		
		//width = newimg.offsetWidth;				
		//height = newimg.offsetHeight;
		newimg.style.top = Math.random() * (parentHeight - height);		
		//alert(newimg.style.top);
		//alert(width);
		imStr[i] = new capImg(newimg, width, height, 0, 0);
		slide(imStr[i]);
	}		
}

function slide(imStruct)
{
	var sliding = false;
	var slidepos = 0;
	var newimg;
	
		
	var top = 0, right = 100, bottom = 100, left = 1; width = imStruct.width, height = imStruct.newimg.offsetHeight;
	
	bottom = height;
	
	sliding = clearInterval(sliding);	
	
	//slidepos = newimg.style.right;
	
	slidepos = parseInt(imStruct.newimg.style.right, 10);
	//alert(slidepos);
	imStruct.opacity = 0;//newimg.style.opacity;	
	right = Math.min(Math.max(slidepos + width, 0), width);
	bottom = height;
	imStruct.newimg.style.clip = "rect("+top+", "+right+", "+bottom+", "+left+")";
	left =  Math.max(slidepos + width - parentWidth, 0);
	//alert(11);
	sliding = setInterval (function(){		
		if (left == width)
		{
			sliding = clearInterval(sliding);	
			imStruct.opacity = 0;
			//alert(slidepos);
		}
		else if (parentWidth - slidepos < width )
		{
			
			left++;
			imStruct.newimg.style.clip = "rect("+top+", "+right+", "+bottom+", "+left+")";
			imStruct.opacity -= 0.01;
			imStruct.newimg.style.opacity = imStruct.opacity;
			//alert(slidepos);
		}
		else if (right < width)
		{
			right++;
			imStruct.newimg.style.clip = "rect("+top+", "+right+", "+bottom+", "+left+")";
		}
		
		if ( imStruct.opacity < 1)
		{
			imStruct.opacity += 0.01;
			//alert(imStruct.opacity);
			imStruct.newimg.style.opacity = imStruct.opacity;			
		}
		//alert(slidepos);
		slidepos++;
		
		imStruct.newimg.style.right = slidepos;			
	}, 1);
}

