<?php	
function cap()
{
echo"
	<table class = 'cap_table' id = 'cap_table' border = '0'> <!--//TODO link-->
		<tr>						
			<th>
				<div class = 'cap_div' id = 'logo' onclick=\"location.href='/index.php';\"> <!--//TODO link-->
				<NOBR class = 'cap_logo'  id = 'logo_text' >PRINTABU</NOBR>
				</div>
			</th>
		</tr>		
	</table>
";
}